date: 2017-05-22
corpus:normal speech + rvb speech + xmos(ch+tw)
noise:64 gau
speech:128 gau

